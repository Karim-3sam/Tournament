
-- --------------------------------------------------------

--
-- Table structure for table `participates`
--

DROP TABLE IF EXISTS `participates`;
CREATE TABLE `participates` (
  `id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `username` longtext NOT NULL,
  `created_at` date NOT NULL,
  `tournament_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
